<?php

use App\Models\Locations;
use App\Models\Setting;
use App\Models\User;


function login_id($id = "")
{
    if (!empty($id)) {
        return $id;
    }
    // if (session('location_id')) {
    //     return session('location_id');
    // }
    // if (request()->has('location_id')) {
    //     return request()->has('location_id');
    // }
    $id = auth()->user()->id;

    if (auth()->user()->role == 1) {
        return $id;
    }
    return $id;
}

// Set Custom Fields
if (!function_exists('setCustomFields')) {
    function setCustomFields($request)
    {


        // ['status'=>'12','mydata'=>['value'=>'2','type'=>'MULTIPLE_OPTIONS','options'=>['1','2','3']]];
        $user_custom_fields = new \stdClass;
        try {
            $request_array = [];
            foreach ($request as $key => $value) {
                $key  = str_replace([' ', '_'], '', $key);
                $key = strtolower($key);
                $request_array[$key] = $value;
            }


            $ghl_custom_values = ghl_api_call('custom-fields');

            // dd($ghl_custom_values);
            $custom_values = $ghl_custom_values;

            if (property_exists($custom_values, 'customFields')) {
                $custom_values = $custom_values->customFields;

                $custom_values = array_filter($custom_values, function ($value) use ($request_array) {
                    $kn = strtolower(str_replace([' ', '_'], '', $value->name));
                    // $kn = strtolower(str_replace(' ', '_', $value->name));
                    return in_array($kn, array_keys($request_array));
                });
                // dd($custom_values);
                foreach ($custom_values as $key => $custom) {
                    $key  = str_replace([' ', '_'], '', $custom->name);
                    $key = strtolower($key);
                    $custom->value = $request_array[$key];
                    $request_array[$key] = $custom;
                }
                //   dd($custom_values);
                $i = 0;
                $v = 0;
                $all_keys = array_keys($request);

                foreach ($request_array as $key => $custom) {
                    $i++;
                    $value = '';
                    $title = $all_keys[$v];
                    $v++;
                    $id = null;
                    $lttitle = strtolower($title);
                    $type = strpos($lttitle, 'date') !== false ? 'TEXT' : 'TEXT';
                    if ($type == 'TEXT') {
                        $type = strpos($lttitle, 'amount') !== false || strpos($key, 'total_paid') !== false || strpos($lttitle, 'grand_total') !== false ? 'MONETORY' : 'TEXT';
                    }
                    $name = str_replace('_', ' ', $title);
                    $name = ucwords($name);
                    $vdata = ['name' => $name];

                    if (is_object($custom)) {
                        $id = $custom->id;
                        $value = $custom->value;
                        if (is_object($value)) {
                            $options = $value->options ?? [];
                            $type = $value->type ?? $type;
                            $value = $value->value ?? '';
                        }
                        $options = [];
                        $always = false;
                        $ignore = false;
                        $isreturn = false;
                        if (is_array($value)) {
                            $always = isset($value['options']);
                            $isreturn = isset($value['isreturn']);
                            $ignore = isset($value['ignore']); // in order to stop updating
                            $options = $value['options'] ?? [];
                            $type = $value['type'] ?? $type;
                            $value = $value['value'] ?? '';

                            if ($isreturn) {
                                $value = $custom;
                                $user_custom_fields->$id = $value;
                            }
                        }
                        if ($ignore) {
                            continue;
                        }
                        $vdata['dataType'] = $type;
                        $vdata['options'] = $options;

                        $vdata = json_encode($vdata);
                        if ($custom->name != $name || $custom->dataType != $type || $always) {
                            if ($i % 15 == 0) {
                                sleep(2);
                            }
                            $abc =  ghl_api_call('custom-fields/' . $custom->id, 'PUT', $vdata, [], true);
                        }
                    } else {



                        $value = $custom;


                        if (is_object($value)) {
                            $options = $value->options ?? [];
                            $type = $value->type ?? $type;
                            $value = $value->value ?? '';
                        }
                        if (is_array($value)) {
                            $options = $value['options'] ?? [];
                            $type = $value['type'] ?? $type;
                            $value = $value['value'] ?? '';
                        }




                        $vdata['dataType'] = $type ?? 'TEXT';
                        $vdata['pickListOptions'] = $options ?? '';

                        $vdata = json_encode($vdata);
                        if ($i % 15 == 0) {
                            sleep(2);
                        }

                        // dd($vdata);
                        // ghl_api_call('custom-fields/' . $custom->id, 'PUT', $vdata,[], true);
                        $cord = ghl_api_call('custom-fields', 'POST', $vdata, [], true);
                        // dd($abc);
                        if ($cord && property_exists($cord, 'id')) {
                            $id = $cord->id;
                        }
                    }

                    if ($id) {
                        $user_custom_fields->$id = $value;
                    }
                }
            }
        } catch (\Exception $e) {
        }
        return $user_custom_fields;
    }
}


// sendTagOrCustomFieldsToGhl 
if (!function_exists('sendTagOrCustomFieldsToGhl')) {
    function sendTagOrCustomFieldsToGhl($contact_id, $tag = '', $customFields)
    {

        if (!is_object($contact_id)) {
            $contact_id = str_replace(' ', '', $contact_id);
            $response = ghl_api_call('contacts/' . $contact_id);
        } else {
            $response = new \stdClass;
            $response->contact = $contact_id;
        }
        if ($response && property_exists($response, 'contact')) {
            $contact = $response->contact;


            if (!empty($tag)) {
                if (!is_array($contact->tags)) {
                    $contact->tags = [];
                }
                if (is_array($tag)) {
                    $contact->tags = array_merge($contact->tags, $tag);
                } else {
                    $contact->tags[] = $tag;
                }
            }


            if ($customFields) {
                $contact->customField = $customFields;
            }

            $response = ghl_api_call('contacts/' . $contact_id, 'PUT', json_encode($contact), [], true);
        }
    }
}



function company_user($location = '', $key = 'location')
{
    if (!empty($location)) {
        return $loc = \App\Models\User::where($key, $location)->where('role', company_role())->first();
    } else if (\Auth::check()) {
        $user = auth()->user();
        if ($user->role == 1) {
            return $user->addedby;
        }
        return $user;
    }
}

function get_api_key()
{
    $cid = session('c_id');
}

function ghl_api_call($url = '', $method = 'get', $data = '', $headers = [], $json = false, $api_key = '')
{

    $baseurl = 'https://rest.gohighlevel.com/v1/';

    if (empty($api_key)) {
        $api_key = session('g_key');
    }
    $bearer = 'Bearer ' . $api_key;
    $headers['Authorization'] = $bearer;
    $headers['Content-Type'] = "application/json";
    $client = new \GuzzleHttp\Client(['http_errors' => false, 'headers' => $headers]);

    $options = [];
    if (!empty($data)) {
        $options['body'] = $data;
    }
    $url1 = $baseurl . $url;
    $response = $client->request($method, $url1, $options);

    $bd = $response->getBody()->getContents();

    $bd = json_decode($bd);
    //  dd($bd);
    return $bd;
}




// Planning Center Oauth Config

function pc_configs()
{
    $config = [
        'auth_mode' => 'oauth2',
        'ClientID' => env('CLIENT_ID'),
        'ClientSecret' => env('CLIENT_SECRET'),
        'RedirectURI' => route('quickbook.callback'),
        'scope' => '',
        'baseUrl' => ''
    ];
    return $config;
}
