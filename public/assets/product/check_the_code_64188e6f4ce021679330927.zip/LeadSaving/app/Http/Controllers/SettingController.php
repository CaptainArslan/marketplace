<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Hash;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function add()
    {
        $setting = Setting::first();
        return view('admin.setting.add', get_defined_vars());
    }

    public function save(Request $request, $id = null)
    {
        dd("Under Construction");
        $request->validate([

            'name' => 'required',
        ]);

        $data = [
            "name" => $request->name,
        ];

        Setting::updateorCreate([
            'id' => $id,
        ], $data);

        return redirect()->route('setting.add')->with('success', 'Setting has been saved.');
    }
}
