<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PlanningCenterController extends Controller
{
    public function connect(){
        
    }
}
